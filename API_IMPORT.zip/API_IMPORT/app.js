const express = require('express');
const app = express();


app.use(express.json({ type: 'application/json' }));

app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/urgency', require('./routes/urgencyRoutes'));
app.use('/api/consultations', require('./routes/consultationsRoutes'));
app.use('/api/surgeries', require('./routes/surgeryRoutes'));

module.exports = app;
