const express = require('express');
const router = express.Router();

const authenticate = require('../middlewares/authMiddleware');
const xmlValidationMiddleware = require('../middlewares/XmlValidation');
const consultationsController = require('../controllers/consultationsController');



/**
 * @swagger
 * /api/consultations/submit:
 *   post:
 *     summary: Submeter relatório de consultas
 *     description: Recebe um XML com dados estatísticos de consultas externas.
 *     tags:
 *       - Consultas
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/xml:
 *           schema:
 *             type: string
 *             example: |
 *               <ConsultationsRegister>
 *                 <Header>...</Header>
 *                 <Data>...</Data>
 *               </ConsultationsRegister>
 *     responses:
 *       201:
 *         description: Relatório de consultas aceite
 *       400:
 *         description: XML inválido
 *       401:
 *         description: Não autenticado
 */
router.post(
    '/submit',
    authenticate,
    xmlValidationMiddleware,
    consultationsController.createConsultationReport
);

module.exports = router;
