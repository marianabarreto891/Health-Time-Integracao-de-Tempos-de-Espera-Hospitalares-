
const express = require('express');
const router = express.Router();

const authenticate = require('../middlewares/authMiddleware');
const xmlValidationMiddleware = require('../middlewares/XmlValidation');
const urgencyController = require('../controllers/urgencyController');


console.log('DEBUG authenticate:', typeof authenticate);
console.log('DEBUG xmlValidationMiddleware:', Array.isArray(xmlValidationMiddleware), xmlValidationMiddleware);
console.log('DEBUG createUrgency:', typeof urgencyController.createUrgency);


/**
 * @swagger
 * /api/urgency/submit:
 *   post:
 *     summary: Submeter registo de urgência
 *     description: Recebe um documento XML validado por XSD com dados de urgência hospitalar.
 *     tags:
 *       - Urgências
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/xml:
 *           schema:
 *             type: string
 *             example: |
 *               <UrgencyRegister>
 *                 <Header>...</Header>
 *                 <Data>...</Data>
 *               </UrgencyRegister>
 *     responses:
 *       201:
 *         description: Registo de urgência aceite
 *       400:
 *         description: XML inválido
 *       401:
 *         description: Não autenticado
 */
router.post(
    '/submit',
    authenticate,
    xmlValidationMiddleware, 
    urgencyController.createUrgencyReport
);

module.exports = router;