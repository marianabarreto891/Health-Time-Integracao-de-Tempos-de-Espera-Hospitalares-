const express = require('express');
const router = express.Router();

const authenticate = require('../middlewares/authMiddleware');
const xmlValidationMiddleware = require('../middlewares/XmlValidation');
const surgeryController = require('../controllers/surgeryController');


/**
 * @swagger
 * /api/surgeries/submit:
 *   post:
 *     summary: Submeter relatório de cirurgias
 *     description: Recebe um XML com dados de cirurgias e tempos médios de espera.
 *     tags:
 *       - Cirurgias
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/xml:
 *           schema:
 *             type: string
 *             example: |
 *               <SurgeryReport>
 *                 <Header>...</Header>
 *                 <SurgicalData>...</SurgicalData>
 *               </SurgeryReport>
 *     responses:
 *       201:
 *         description: Relatório de cirurgias aceite
 *       400:
 *         description: XML inválido
 *       401:
 *         description: Não autenticado
 */
router.post(
    '/submit',
    authenticate,
    xmlValidationMiddleware,
    surgeryController.createSurgeryReport
);

module.exports = router;
