const { MongoClient } = require('mongodb');

const uri = 'mongodb+srv://ventura11david_db_user:cJ2FWzuiM19bth1W@cluster0.krbwicp.mongodb.net/';
const client = new MongoClient(uri);

let db;

async function connectToMongo() {
    if (!db) {
        await client.connect();
        db = client.db('HealthTime');
        console.log('Ligação ao MongoDB estabelecida');
    }
    return db;
}

function getDb() {
    if (!db) {
        throw new Error('MongoDB não ligado!');
    }
    return db;
}

module.exports = { connectToMongo, getDb };
