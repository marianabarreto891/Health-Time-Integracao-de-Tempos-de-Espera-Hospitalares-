const app = require('./app');
const { connectToMongo } = require('./config/connectBd');

async function startServer() {
    try {
        await connectToMongo();

        app.listen(3000, () => {
            console.log('Servidor disponível em http://localhost:3000');
        });

    } catch (err) {
        console.error('Erro ao arrancar servidor:', err);
        process.exit(1);
    }
}

startServer();
