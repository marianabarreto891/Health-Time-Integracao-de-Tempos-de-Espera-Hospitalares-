const { getDb } = require('../config/connectBd');

exports.createSurgeryReport = async (req, res) => {
  try {
    const root = req.body.SurgeryReport;

    if (!root || !root.Header || !root.SurgicalData) {
      return res.status(400).json({
        status: 'error',
        message: 'Estrutura XML inválida (Cirurgias)'
      });
    }

    const entriesRaw = root.SurgicalData.SurgeryEntry;

    if (!entriesRaw) {
      return res.status(400).json({
        status: 'error',
        message: 'Nenhuma cirurgia encontrada'
      });
    }

    const entries = Array.isArray(entriesRaw)
      ? entriesRaw
      : [entriesRaw];

    const db = getDb();
    const collection = db.collection('CirurgiasSEC');
    const servicesCollection = db.collection('ServicosSEC');

    for (const e of entries) {
      const service = await servicesCollection.findOne({
        ServiceKey: e.serviceId,
        Speciality: e.Specialty,
        Type: 'Cirurgia'
      });

      if (!service) {
        return res.status(400).json({
          status: 'error',
          message: `Serviço inválido: ${e.serviceId} - ${e.Specialty}`
        });
      }
    }

    const documents = entries.map(e => ({
      institutionId: root.Header.InstitutionId,
      referencePeriod: root.Header.ReferencePeriod,

      serviceId: e.serviceId,
      specialty: e.Specialty,
      priority: e.priority,

      waitingList: e.WaitingListCounts,
      numPatients:
        e.WaitingListCounts.General +
        e.WaitingListCounts.NonOncological +
        e.WaitingListCounts.Oncological,

      averageWaitingTime: e.AverageWaitTimeDays,

      importedAt: new Date()
    }));

    await collection.insertMany(documents);

    return res.status(201).json({
      status: 'success',
      message: 'Relatório de cirurgias armazenado',
      inserted: documents.length
    });

  } catch (error) {
    console.error(error);
    return res.status(500).json({
      status: 'error',
      message: 'Erro ao processar cirurgias'
    });
  }
};
