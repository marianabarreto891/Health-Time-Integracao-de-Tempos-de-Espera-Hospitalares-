const { getDb } = require('../config/connectBd');

exports.createConsultationReport = async (req, res) => {
    try {
        const root = req.body.ConsultationsRegister;

        if (!root || !root.Data || !root.Data.Consultation) {
            return res.status(400).json({
                status: 'error',
                message: 'Estrutura XML inválida'
            });
        }


        const consultations = Array.isArray(root.Data.Consultation)
            ? root.Data.Consultation
            : [root.Data.Consultation];



    const db = getDb();
    const collection = db.collection('ConsultasSEC');
    const servicesCollection = db.collection('ServicosSEC');

    for (const c of consultations) {
      const service = await servicesCollection.findOne({
        ServiceKey: c.servicekey,
        Speciality: c.Speciality,
        Type: 'Consulta'
      });

      if (!service) {
        return res.status(400).json({
          status: 'error',
          message: `Serviço inválido: ${c.servicekey} - ${c.Speciality}`
        });
      }
    }
        const documents = consultations.map(c => ({
            institutionId: root.Header.InstitutionId,
            hospital: root.Header.HospitalName,
            period: root.Header.Period,
            averageWaitingTime: c.AverageResponseTimes.Normal + 
            c.AverageResponseTimes.Priority + 
            c.AverageResponseTimes.VeryPriority,
            numPatients:  c.WaitingListCounts.General +
                c.WaitingListCounts.NonOncological +
                c.WaitingListCounts.Oncological,
            priority: c.priority,
            speciality: c.Speciality,
            servicekey: c.servicekey, 
            targetPopulation: c.TargetPopulation,
            waitingList: c.WaitingListCounts,
            avgResponseTimes: c.AverageResponseTimes,
      
            importedAt: new Date()
        }));

        await collection.insertMany(documents);

        return res.status(201).json({
            status: 'success',
            message: 'Relatório de consultas armazenado',
            inserted: documents.length
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({
            status: 'error',
            message: 'Erro ao processar consultas'
        });
    }
};
