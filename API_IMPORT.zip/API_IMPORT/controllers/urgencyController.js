const { getDb } = require('../config/connectBd');

exports.createUrgencyReport = async (req, res) => {
    try {
        const root = req.body.UrgencyRegister;

        if (!root || !root.Header || !root.Data) {
            return res.status(400).json({
                status: 'error',
                message: 'Estrutura XML inválida (Urgências)'
            });
        }

        const db = getDb();
        const collection = db.collection('UrgenciasSEC');

        const document = {
            hospitalId: root.Header.hospitalId,
            HospitalName: root.Header.HospitalName,
            timestamp: new Date(root.Header.Timestamp),
            emergencyType: root.Data.emergencyType,
            openState: root.Data.OpenState,
            address: root.Data.Address,
            waiting: root.Data.waiting,
            observing: root.Data.ObservingPatients,
            importedAt: new Date()
        };

        await collection.insertMany([document]);

        return res.status(201).json({
            status: 'success',
            message: 'Relatório de urgência armazenado'
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({
            status: 'error',
            message: 'Erro ao processar urgências'
        });
    }
};
