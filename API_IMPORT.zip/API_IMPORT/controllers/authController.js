const jwt = require('jsonwebtoken');
const SECRET_KEY = require('../config/auth').SECRET_KEY;

exports.login = (req, res) => {

    let username, password;

    if (req.body.username && req.body.password) {
        username = req.body.username;
        password = req.body.password;
    } 
    else if (req.body.login) {
        username = req.body.login.username;
        password = req.body.login.password;
    }

    if (!username || !password) {
        return res.status(400).json({
            status: 'error',
            message: 'Credenciais em falta'
        });
    }

    if (username === 'admin' && password === 'password') {

        const token = jwt.sign(
            { username },
            SECRET_KEY,
            { expiresIn: '1h' }
        );

        return res.json({
            status: 'success',
            token
        });
    }

    return res.status(401).json({
        status: 'error',
        message: 'Credenciais inválidas'
    });
};
