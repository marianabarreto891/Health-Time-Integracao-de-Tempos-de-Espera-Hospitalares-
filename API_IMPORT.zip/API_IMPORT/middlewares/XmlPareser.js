const { XMLParser } = require('fast-xml-parser');

const parser = new XMLParser({
    explicitArray: false,
    ignoreAttributes: false,
    attributeNamePrefix: "@_", 
    numberParseOptions: {
        hex: true,
        leadingZeros: false,
    }
});

const pareser  = parser;
module.exports = pareser;