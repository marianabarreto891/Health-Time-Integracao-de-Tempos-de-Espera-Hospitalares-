const { stat } = require('fs');
const jwt = require('jsonwebtoken');
const SECRET_KEY = require('../config/auth').SECRET_KEY;


function authenticateToken(req, res, next) {

    const authHeader = req.headers['authorization'];

    const token = authHeader && authHeader.split(' ')[1];

    if (!token){
        return res.sendStatus(401).json({status: 'fail', message: 'Invalid token' });
    }

    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err){
            return res.sendStatus(403).json({status: 'fail', message: 'Invalid token' });
        }
        req.user = user;
        next();
    });
}

const authenticate = authenticateToken;
module.exports = authenticate;