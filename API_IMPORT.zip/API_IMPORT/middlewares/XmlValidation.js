const validator = require('xsd-schema-validator');
const parser = require('./XmlPareser');
const express = require('express');
const fs = require('fs');
const path = require('path');

const xmlValidationMiddleware = [
    express.text({ type: ['application/xml', 'text/xml'] }),

    async (req, res, next) => {
        if (
            req.get('Content-Type') &&
            req.get('Content-Type').includes('xml') &&
            typeof req.body === 'string'
        ) {
            console.log('--> Recebida requisição XML. A validar...');

            const schemaFile = getSchemaForXml(req.body);

            if (!schemaFile) {
                return res.status(400).json({
                    status: 'error',
                    message: 'Tipo de documento XML desconhecido.'
                });
            }
            const schemaPath = path.join(
                __dirname,
                '..',
                'schemas',
                schemaFile
            );

            

            if (!fs.existsSync(schemaPath)) {
                console.error(`XSD não encontrado: ${schemaPath}`);
                return res.status(500).json({
                    status: 'error',
                    message: `XSD não encontrado: ${schemaFile}`
                });
            }

            try {
                await validator.validateXML(req.body.trim(), schemaPath);

                const parsed = parser.parse(req.body);
                req.body = parsed;

                console.log(`--> XML válido (${schemaFile}) e convertido.`);
                next();

            } catch (err) {
                console.error('Erro na validação:', err);

                return res.status(400).json({
                    status: 'error',
                    message: 'XML inválido ou não conforme com o XSD',
                    details: err.message
                });
            }
        } else {
            next();
        }
    }
];

function getSchemaForXml(xmlString) {
    if (xmlString.includes('<UrgencyRegister')) {
        return 'Urgency.xsd';
    }
    if (xmlString.includes('<ConsultationsRegister')) {
        return 'Consultations.xsd';
    }
    if (xmlString.includes('<SurgeryReport')) {
        return 'Sugeri.xsd';
    }
    return null;
}

module.exports = xmlValidationMiddleware;
