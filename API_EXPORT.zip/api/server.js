require("dotenv").config();
const express = require("express");
const cors = require("cors");
const { connectToDb } = require("./config/db");

connectToDb((err) => {
  if (!err) {
    app.listen(PORT, () => {
      console.log(`Servidor ativo na porta ${PORT} e ligado ao MongoDB Atlas`);
    });
  } else {
    console.error("Falha ao ligar à BD:", err);
  }
});

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

const analiseRoutes = require("./routes/analises");
app.use("/api/analise", analiseRoutes);

app.listen(PORT, () => {
  console.log(`API de Visualização Health Time a correr na porta ${PORT}`);
});
