const express = require("express");
const { getDb } = require("../config/db");
const router = express.Router();

//1. Média de utentes em espera por tipologia (Urgências)

router.get("/media-espera", async (req, res) => {
  const db = getDb();
  const { inicio, fim } = req.query;

  try {
    const resultados = await db
      .collection("UrgenciasSEC")
      .aggregate([
        {
          $match: {
            timestamp: {
              $gte: new Date(inicio),
              $lte: new Date(fim),
            },
          },
        },
        {
          $group: {
            _id: "$emergencyType",
            naoUrgente: { $avg: "$waiting.nonUrgent" },
            poucoUrgente: { $avg: "$waiting.lessUrgent" },
            urgente: { $avg: "$waiting.urgent" },
            muitoUrgente: { $avg: "$waiting.veryUrgent" },
          },
        },
        {
          $project: {
            _id: 0,
            tipologia: "$_id",
            medias: {
              naoUrgente: { $round: ["$naoUrgente", 2] },
              poucoUrgente: { $round: ["$poucoUrgente", 2] },
              urgente: { $round: ["$urgente", 2] },
              muitoUrgente: { $round: ["$muitoUrgente", 2] },
            },
          },
        },
      ])
      .toArray();

    res.json(resultados);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});

//2. Percentagem por triagem num hospital por período do dia

router.get("/percentagem-triagem", async (req, res) => {
  const db = getDb();
  const { hospitalId, inicio, fim } = req.query;

  try {
    const resultados = await db
      .collection("UrgenciasSEC")
      .aggregate([
        {
          $match: {
            hospitalId: Number(hospitalId),
            timestamp: {
              $gte: new Date(inicio),
              $lte: new Date(fim),
            },
          },
        },
        {
          $addFields: {
            hora: { $hour: "$timestamp" },
            periodoDia: {
              $switch: {
                branches: [
                  { case: { $lt: ["$hora", 12] }, then: "manhã" },
                  { case: { $lt: ["$hora", 20] }, then: "tarde" },
                ],
                default: "noite",
              },
            },
          },
        },
        {
          $project: {
            periodoDia: 1,
            waiting: { $objectToArray: "$waiting" },
          },
        },
        { $unwind: "$waiting" },
        {
          $group: {
            _id: { periodo: "$periodoDia", categoria: "$waiting.k" },
            total: { $sum: "$waiting.v" },
          },
        },
        {
          $group: {
            _id: "$_id.periodo",
            totalPeriodo: { $sum: "$total" },
            detalhes: {
              $push: {
                categoria: "$_id.categoria",
                valor: "$total",
              },
            },
          },
        },
        { $unwind: "$detalhes" },
        {
          $project: {
            _id: 0,
            periodoDia: "$_id",
            categoria: "$detalhes.categoria",
            percentagem: {
              $multiply: [
                { $divide: ["$detalhes.valor", "$totalPeriodo"] },
                100,
              ],
            },
          },
        },
      ])
      .toArray();

    res.json(resultados);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});

router.get("/media-pediatria-regiao", async (req, res) => {
  const db = getDb();
  const { tipo = "pedi" } = req.query;

  const dataInicio = new Date("2025-01-01");

  try {
    const resultados = await db
      .collection("UrgenciasSEC")
      .aggregate([
        {
          $match: {
            emergencyType: { $regex: new RegExp(tipo, "i") },
            timestamp: { $gte: dataInicio },
          },
        },
        {
          $lookup: {
            from: "HospitaisSEC",
            localField: "hospitalId",
            foreignField: "_id",
            as: "hospital",
          },
        },
        { $unwind: "$hospital" },
        {
          $group: {
            _id: "$hospital.NUTS.NUTSIIIDescription",
            tempoMedio: {
              $avg: {
                $add: [
                  "$waiting.nonUrgent",
                  "$waiting.lessUrgent",
                  "$waiting.urgent",
                  "$waiting.veryUrgent",
                ],
              },
            },
          },
        },
      ])
      .toArray();

    res.json(resultados);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});

//4. Diferença Oncologia vs Não-Oncologia (Consultas)

router.get("/comparativo-oncologia", async (req, res) => {
  const db = getDb();
  const { hospital, especialidade, ano } = req.query;

  try {
    const dados = await db
      .collection("ConsultasSEC")
      .aggregate([
        {
          $match: {
            hospital,
            "period.year": Number(ano),
            speciality: { $regex: especialidade, $options: "i" },
          },
        },
        {
          $group: {
            _id: {
              $cond: [
                { $regexMatch: { input: "$priority", regex: /oncol/i } },
                "Oncologia",
                "NaoOncologia",
              ],
            },
            media: { $avg: "$averageWaitingTime" },
          },
        },
      ])
      .toArray();

    res.json(dados);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});

//5. Cirurgia – lista geral vs oncológica

router.get("/comparativo-cirurgia", async (req, res) => {
  const db = getDb();
  const { hospital, ano } = req.query;

  try {
    const dados = await db
      .collection("CirurgiasSEC")
      .aggregate([
        {
          $match: {
            hospital,
            "period.year": Number(ano),
          },
        },
        {
          $group: {
            _id: {
              especialidade: "$speciality",
              lista: "$priority",
            },
            media: { $avg: "$averageWaitingTime" },
          },
        },
      ])
      .toArray();

    res.json(dados);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});

//6. Discrepância Consulta vs Cirurgia

router.get("/discrepancia-servicos", async (req, res) => {
  const db = getDb();
  const { hospital, especialidade, ano } = req.query;

  try {
    const consultas = await db
      .collection("ConsultasSEC")
      .aggregate([
        {
          $match: {
            hospital,
            speciality: especialidade,
            "period.year": Number(ano),
          },
        },
        { $group: { _id: null, media: { $avg: "$averageWaitingTime" } } },
      ])
      .toArray();

    const cirurgias = await db
      .collection("CirurgiasSEC")
      .aggregate([
        {
          $match: {
            hospital,
            speciality: especialidade,
            "period.year": Number(ano),
          },
        },
        { $group: { _id: null, media: { $avg: "$averageWaitingTime" } } },
      ])
      .toArray();

    res.json({
      mediaConsulta: consultas[0]?.media || 0,
      mediaCirurgia: cirurgias[0]?.media || 0,
    });
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});

//7. Top 10 hospitais urgências pediátricas

router.get("/top10-hospitais", async (req, res) => {
  const db = getDb();

  try {
    const dados = await db
      .collection("UrgenciasSEC")
      .aggregate([
        { $match: { emergencyType: { $regex: /pedi/i } } },
        {
          $lookup: {
            from: "HospitaisSEC",
            localField: "hospitalId",
            foreignField: "_id",
            as: "hospital",
          },
        },
        { $unwind: "$hospital" },
        {
          $group: {
            _id: "$hospitalId",
            nome: { $first: "$hospital.HospitalName" },
            regiao: { $first: "$hospital.NUTS.NUTSIIIDescription" },
            contacto: { $first: "$hospital.Contacts" },
            tempoMedio: {
              $avg: {
                $avg: [
                  "$waiting.nonUrgent",
                  "$waiting.lessUrgent",
                  "$waiting.urgent",
                  "$waiting.veryUrgent",
                ],
              },
            },
          },
        },
        { $sort: { tempoMedio: 1 } },
        { $limit: 10 },
      ])
      .toArray();

    res.json(dados);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});

//8. Evolução temporal 15 em 15 minutos e top3 picos

router.get("/evolucao-temporal-geral", async (req, res) => {
  const db = getDb();
  const { data } = req.query;

  const inicio = new Date(`${data}T00:00:00`);
  const fim = new Date(`${data}T23:59:59`);

  try {
    const evolucao = await db
      .collection("UrgenciasSEC")
      .aggregate([
        {
          $match: {
            timestamp: { $gte: inicio, $lte: fim },
            emergencyType: { $regex: /geral/i },
          },
        },
        {
          $project: {
            hora: { $hour: "$timestamp" },
            intervalo: {
              $subtract: [
                { $minute: "$timestamp" },
                { $mod: [{ $minute: "$timestamp" }, 15] },
              ],
            },
            afluencia: {
              $add: [
                "$waiting.nonUrgent",
                "$waiting.lessUrgent",
                "$waiting.urgent",
                "$waiting.veryUrgent",
              ],
            },
          },
        },
        {
          $group: {
            _id: { hora: "$hora", intervalo: "$intervalo" },
            total: { $sum: "$afluencia" },
          },
        },
        { $sort: { "_id.hora": 1, "_id.intervalo": 1 } },
      ])
      .toArray();

    const top3 = [...evolucao].sort((a, b) => b.total - a.total).slice(0, 3);

    res.json({ evolucao, top3 });
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});

module.exports = router;
